# LotteryGeneratorPhp
Mobile web application to generate lottery numbers using php


Run app using
```bash
php -S localhost:8000
```